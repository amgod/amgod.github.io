#!/bin/sh
jekyll serve --watch  -d /tmp/jekyll
